
import React, { useState } from 'react';
import { 
  Calendar, 
  MapPin, 
  Ticket, 
  Star, 
  Check, 
  Plus, 
  Minus,
  MessageCircle,
  Users,
  BookOpen,
  Award,
  ArrowRight,
  Heart,
  Instagram,
  Facebook,
  Youtube,
  Utensils,
  Globe,
  Coins,
  Zap,
  Palette,
  Lightbulb,
  TrendingUp,
  Target,
  RefreshCw,
  Quote,
  Flame,
  Trophy,
  Mic,
  Link as LinkIcon,
  ShoppingBag,
  HandMetal,
  ShieldCheck,
  Leaf,
  Clock,
  Lock
} from 'lucide-react';

// --- Components ---

const ClassificationBadge = ({ className = "" }: { className?: string }) => (
  <div className={`flex items-center gap-3 px-4 py-2 border-2 border-[#FFCC00] rounded-2xl text-white ${className}`}>
    <div className="flex flex-col text-[10px] font-black uppercase leading-tight text-right tracking-tight">
      <span>Classificação</span>
      <span>12 Anos</span>
    </div>
    <div className="w-10 h-10 bg-[#FFCC00] rounded-lg flex items-center justify-center font-black text-xl text-[#600060] shadow-sm">
      12
    </div>
  </div>
);

const MarqueeText = () => (
  <div className="marquee-container py-6 border-y border-white/10 relative z-20">
    <div className="marquee-content font-title text-2xl tracking-[0.2em] whitespace-nowrap text-white">
      CONFEITAR BRASIL <span className="cora">2026</span> • 14ª EDIÇÃO • CONFEITAR BRASIL <span className="cora">2026</span> • 14ª EDIÇÃO •&nbsp;
      CONFEITAR BRASIL <span className="cora">2026</span> • 14ª EDIÇÃO • CONFEITAR BRASIL <span className="cora">2026</span> • 14ª EDIÇÃO •&nbsp;
    </div>
  </div>
);

const PhotoMarquee = () => (
  <div 
    className="marquee-container py-10 overflow-hidden border-y border-white/5" 
    style={{ background: 'linear-gradient(90deg, #4D004D 0%, #600060 50%, #9900cc 100%)' }}
  >
    <div className="marquee-photos flex gap-6 whitespace-nowrap items-center">
      <img src="input_file_0.png" className="h-20 md:h-28 mx-10 opacity-80" alt="Logo 0" />
      <img src="input_file_1.png" className="h-20 md:h-28 mx-10 opacity-80" alt="Logo 1" />
      <img src="input_file_2.png" className="h-20 md:h-28 mx-10 opacity-80" alt="Logo 2" />
      {[1, 2, 3].map((i) => (
        <img 
          key={i} 
          src={`https://picsum.photos/seed/pastry${i}/400/250`} 
          className="w-72 md:w-96 rounded-2xl border-2 border-white/5 shadow-xl grayscale hover:grayscale-0 transition-all duration-500" 
          alt={`Evento ${i}`} 
        />
      ))}
      <img src="input_file_0.png" className="h-20 md:h-28 mx-10 opacity-80" alt="Logo 0" />
      <img src="input_file_1.png" className="h-20 md:h-28 mx-10 opacity-80" alt="Logo 1" />
      <img src="input_file_2.png" className="h-20 md:h-28 mx-10 opacity-80" alt="Logo 2" />
    </div>
  </div>
);

const FAQItem = ({ question, answer }: { question: string, answer: string, key?: React.Key }) => {
  const [isOpen, setIsOpen] = useState(false);
  return (
    <div className="border-b border-white/10">
      <button 
        onClick={() => setIsOpen(!isOpen)}
        className="w-full py-6 flex justify-between items-center text-left hover:text-[#FFCC00] transition-colors"
      >
        <span className="text-lg md:text-xl font-bold font-body">{question}</span>
        {isOpen ? <Minus className="yellow-text shrink-0" /> : <Plus className="yellow-text shrink-0" />}
      </button>
      <div className={`overflow-hidden transition-all duration-300 ${isOpen ? 'max-h-[500px] pb-6' : 'max-h-0'}`}>
        <p className="text-gray-300 text-base md:text-lg leading-relaxed font-body">{answer}</p>
      </div>
    </div>
  );
};

// --- Sections ---

const Hero = () => (
  <header className="relative min-h-[95vh] flex flex-col justify-between overflow-hidden bg-[#600060]">
    <div className="absolute inset-0 z-0">
      <video autoPlay muted loop playsInline className="w-full h-full object-cover opacity-40 scale-110">
        <source src="https://assets.mixkit.co/videos/preview/mixkit-confectioner-decorating-a-chocolate-cake-with-cream-40061-large.mp4" type="video/mp4" />
      </video>
      <div className="absolute inset-0 bg-gradient-to-b from-transparent via-[#600060]/80 to-[#600060]"></div>
    </div>

    <div className="container mx-auto px-6 relative z-10 pt-12 md:pt-20 flex flex-col items-center">
      <div className="flex flex-col items-center mb-8">
        <img src="input_file_0.png" alt="MartMinas Apresenta" className="w-40 md:w-56 mb-6" />
        <h1 className="font-title text-2xl md:text-4xl lg:text-5xl text-center leading-tight max-w-6xl text-white">
          O MAIOR EVENTO <span className="cora">GASTRONÔMICO</span> <br className="hidden md:block"/> FEMININO DO BRASIL <span className="text-white">COM FOCO EM CONFEITARIA</span>
        </h1>
      </div>

      <div className="max-w-4xl text-center mb-10 space-y-6">
        <p className="text-lg md:text-3xl font-body text-gray-100 leading-tight">
          O evento que transforma a <span className="font-bold cora">paixão pela cozinha</span> <br className="hidden md:block"/> em um <span className="font-bold text-white border-b-2 border-[#FF00E8]">negócio de sucesso</span>.
        </p>
        <p className="text-base md:text-xl font-body text-gray-300 leading-relaxed max-w-2xl mx-auto">
          <span className="font-bold text-white underline decoration-[#FF00E8]">3 dias</span> de conhecimento prático para você transformar sua paixão em uma fonte de <span className="cora font-bold">renda sólida e crescente</span>.
        </p>
      </div>

      <a href="#ingresso" className="btn-brand animate-pulse-custom px-6 py-5 rounded-full text-sm sm:text-lg md:text-xl shadow-2xl mb-12 whitespace-nowrap text-center">
        GARANTA SEU INGRESSO AGORA
      </a>

      <div className="flex flex-col md:flex-row gap-8 items-center text-center">
        <div className="flex items-center gap-3 font-bold text-lg md:text-xl uppercase">
          <Calendar className="yellow-text" /> 03, 04 e 05 de Março de 2026
        </div>
        <div className="flex items-center gap-3 font-bold text-lg md:text-xl uppercase">
          <MapPin className="yellow-text" /> Expominas BH • Belo Horizonte – MG
        </div>
      </div>

      <ClassificationBadge className="mt-10" />
    </div>
    <div className="h-20"></div>
  </header>
);

const CulturalConnection = () => {
  const connectionItems = [
    "Confeitaria", "Panificação", "Cultura alimentar", "Festas", 
    "Artes (música, teatro e intervenções culturais)", "Empreendedorismo feminino"
  ];

  return (
    <section 
      className="py-24 overflow-hidden"
      style={{ background: 'linear-gradient(90deg, #600060 0%, #7c007c 50%, #9900cc 100%)' }}
    >
      <div className="container mx-auto px-6">
        <h2 className="font-title text-2xl mb-8 tracking-tighter text-center lg:hidden" style={{ color: '#FFCC00' }}>
          O CONFEITAR BRASIL É UM EVENTO CULTURAL, QUE CONECTA:
        </h2>

        <div className="flex flex-col lg:flex-row gap-12 items-stretch">
          <div className="lg:w-1/2 grid grid-cols-2 gap-4 w-full max-w-2xl mx-auto lg:mx-0">
            <div className="flex flex-col gap-4">
              <img 
                src="https://images.unsplash.com/photo-1578985545062-69928b1d9587?auto=format&fit=crop&q=80&w=600&h=800" 
                className="w-full aspect-[3/4] object-cover rounded-2xl border-2 border-white/10 shadow-2xl" 
                alt="Confeitaria Profissional" 
              />
              <img 
                src="https://images.unsplash.com/photo-1555507036-ab1f4038808a?auto=format&fit=crop&q=80&w=600&h=400" 
                className="w-full aspect-[4/3] object-cover rounded-2xl border-2 border-white/10 shadow-2xl" 
                alt="Panificação" 
              />
            </div>
            <div className="flex flex-col gap-4 pt-8">
              <img 
                src="https://images.unsplash.com/photo-1530103043960-ef38714abb15?auto=format&fit=crop&q=80&w=600&h=400" 
                className="w-full aspect-[1/1] object-cover rounded-2xl border-2 border-white/10 shadow-2xl" 
                alt="Cultura e Eventos" 
              />
              <img 
                src="https://images.unsplash.com/photo-1449664421329-1a139ac59715?auto=format&fit=crop&q=80&w=600&h=800" 
                className="w-full aspect-[3/4] object-cover rounded-2xl border-2 border-white/10 shadow-2xl" 
                alt="Networking" 
              />
            </div>
          </div>

          <div className="lg:w-1/2 w-full flex">
            <div 
              className="p-10 md:p-14 rounded-[40px] shadow-2xl flex flex-col justify-between w-full"
              style={{ backgroundColor: '#600060', border: '1px solid rgba(255, 255, 255, 0.1)' }}
            >
              <h2 className="font-title text-2xl md:text-3xl mb-8 tracking-tighter hidden lg:block" style={{ color: '#FFCC00' }}>
                O CONFEITAR BRASIL É UM EVENTO CULTURAL, QUE CONECTA:
              </h2>
              
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 mb-8">
                {connectionItems.map((item, idx) => (
                  <div 
                    key={idx} 
                    className="bg-white p-6 rounded-2xl shadow-md border-b-4 border-[#FF00E8] flex items-center justify-center text-center"
                  >
                    <span className="text-[#600060] font-black text-lg font-body">
                      {item}
                    </span>
                  </div>
                ))}
              </div>

              <p className="text-white text-lg md:text-xl font-body italic leading-relaxed mb-10">
                Criando um ecossistema que valoriza saberes tradicionais e gera renda de forma sustentável.
              </p>

              <a 
                href="#ingresso" 
                className="btn-brand animate-pulse-custom block w-full text-center py-5 rounded-2xl text-lg md:text-xl shadow-xl border-none font-black"
                style={{ backgroundColor: '#FFCC00', color: '#600060' }}
              >
                GARANTIR MINHA VAGA
              </a>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

const WhatMovesUs = () => {
  const pillars = [
    {
      title: "CULTURA GASTRONÔMICA",
      desc: "Valorizamos a riqueza da nossa culinária e a arte de transformar ingredientes em experiências. Aqui você aprende a preservar tradições e inovar com identidade. A gastronomia é patrimônio, e você é parte dessa história.",
      icon: <Utensils className="text-[#FFCC00]" size={32} />
    },
    {
      title: "IMPACTO SOCIAL",
      desc: "Quando uma mulher empreende, toda uma comunidade cresce com ela. Seu sucesso inspira outras mulheres a conquistarem autonomia e dignidade. Juntas, construímos redes de apoio que transformam realidades.",
      icon: <Globe className="text-[#FFCC00]" size={32} />
    },
    {
      title: "GERAÇÃO DE RENDA",
      desc: "Transforme sua habilidade em fonte de renda real e sustentável. Aprenda a precificar com justiça, vender com estratégia e construir um negócio lucrativo que valoriza seu trabalho. Empreender no lar é planejamento, técnica e resultado.",
      icon: <Coins className="text-[#FFCC00]" size={32} />
    },
    {
      title: "TRANSFORMAÇÃO",
      desc: "Você sai daqui com clareza, direção e ferramentas práticas. Sai da dúvida para a ação, do amadorismo para a profissionalização, do \"eu gostaria\" para o \"eu consegui\". E você vai conseguir.",
      icon: <Zap className="text-[#FFCC00]" size={32} />
    },
    {
      title: "ECONOMIA CRIATIVA",
      desc: "A confeitaria é arte, técnica e negócio. Faz parte de um mercado crescente que valoriza talento e criatividade. Ao profissionalizar seu trabalho, você posiciona sua marca como referência em um setor que movimenta bilhões.",
      icon: <Palette className="text-[#FFCC00]" size={32} />
    }
  ];

  return (
    <section className="py-24 bg-[#600060] border-y border-white/5">
      <div className="container mx-auto px-6">
        <div className="max-w-4xl mx-auto text-center mb-20">
          <h2 className="font-title text-4xl md:text-7xl mb-10 text-white">O QUE NOS <span className="cora">MOVE?</span></h2>
          <p className="text-gray-200 text-lg md:text-xl font-body leading-relaxed">
            O Confeitar Brasil valoriza a cultura gastronômica brasileira ao reconhecer a confeitaria e os saberes do lar como expressões de identidade, tradição e geração de renda. O projeto conecta o fazer artesanal à inovação, ao conhecimento técnico e ao empreendedorismo, promovendo impacto social, inclusão produtiva e fortalecimento da economia criativa feminina.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 mb-16">
          {pillars.map((pillar, i) => (
            <div key={i} className={`glass-card p-10 flex flex-col items-center text-center transition-all duration-300 hover:border-[#FFCC00]/50 ${i === 4 ? 'lg:col-span-2 lg:max-w-2xl lg:mx-auto' : ''}`}>
              <div className="w-16 h-16 rounded-full bg-white/5 flex items-center justify-center mb-6">
                {pillar.icon}
              </div>
              <h3 className="font-title text-xl mb-4 text-[#FFCC00]">{pillar.title}</h3>
              <p className="text-gray-300 font-body text-sm leading-relaxed">{pillar.desc}</p>
            </div>
          ))}
        </div>

        <div className="text-center pt-10">
          <div className="inline-block py-6 px-10 border-2 border-[#FF00E8]/30 rounded-full font-title text-xl md:text-2xl tracking-widest text-white shadow-[0_0_30px_rgba(255,0,232,0.1)] leading-snug">
            CONFEITAR BRASIL É <br />
            <span className="cora">CULTURA GASTRONÔMICA</span> <br />
            EM MOVIMENTO.
          </div>
        </div>
      </div>
    </section>
  );
};

const About = () => (
  <section className="py-24 bg-gradient-to-b from-[#600060] to-[#9900CC]">
    <div className="container mx-auto px-6 grid grid-cols-1 lg:grid-cols-2 gap-16 items-start">
      <div className="space-y-10">
        <h2 className="font-title text-3xl sm:text-4xl md:text-6xl leading-tight text-center lg:text-left text-white max-w-lg mx-auto lg:mx-0">
          O QUE É O <br/><span className="cora">CONFEITAR BRASIL?</span>
        </h2>
        <div className="space-y-6 text-gray-200 text-lg md:text-xl font-body leading-relaxed">
          <p className="font-bold text-white text-center lg:text-left">O Maior Evento de Empreendedorismo Gastronômico do Brasil com foco em confeitaria e no empreendedorismo no lar</p>
          <p className="text-center lg:text-left">O Confeitar Brasil 2026 traz para você uma programação cuidadosamente planejada para que você saia do evento não só inspirada, mas com ferramentas concretas para dar o próximo passo rumo ao seu sucesso.</p>
        </div>
        
        <div className="grid grid-cols-1 gap-6 pt-6">
          {[
            { title: "7 Arenas", desc: "Arenas de conhecimento, MartMinas, combate ao vivo, cacau, panificação e muito mais…", icon: <Award className="yellow-text mb-4 shrink-0" size={32}/> },
            { title: "+80 Aulas e Palestras", desc: "Aulas de confeitaria/gastronomia e palestras de empreendedorismo", icon: <BookOpen className="yellow-text mb-4 shrink-0" size={32}/> },
            { title: "+8.200 Vagas Disponíveis", desc: "Evento repleto de vagas e arenas para gerar impacto e transformation", icon: <Users className="yellow-text mb-4 shrink-0" size={32}/> }
          ].map((stat, i) => (
            <div key={i} className="glass-card p-8 flex flex-col md:flex-row items-center md:items-start gap-6 border-l-4 border-[#FF00E8]">
              <div className="flex justify-center">{stat.icon}</div>
              <div className="text-center md:text-left">
                <div className="text-2xl font-title text-white mb-2">{stat.title}</div>
                <div className="text-sm font-body text-gray-300 leading-relaxed">{stat.desc}</div>
              </div>
            </div>
          ))}
        </div>
      </div>
      
      <div className="relative flex justify-center items-center h-auto w-full mt-12 lg:mt-0 lg:sticky lg:top-32">
        <img 
          src="https://opontoforadacurva.com.br/wp-content/uploads/2026/02/PONTO2.webp" 
          className="rodar w-64 md:w-80 opacity-10 absolute pointer-events-none" 
          alt="Decoração" 
        />
        <img 
          src="https://images.unsplash.com/photo-1488477181946-6428a0291777?auto=format&fit=crop&q=80&w=1080&h=1350" 
          className="relative w-full max-w-[360px] aspect-[1080/1350] object-cover rounded-3xl border-4 border-[#FF00E8]/20 shadow-2xl z-10" 
          alt="Confeitaria" 
        />
      </div>
    </div>
  </section>
);

const ForWhom = () => (
  <section className="py-24 bg-[#9900CC] relative overflow-hidden">
    <div className="container mx-auto px-6 flex flex-col lg:flex-row gap-16 items-center">
      <div className="lg:w-1/2">
        <img src="https://images.unsplash.com/photo-1556910103-1c02745aae4d?auto=format&fit=crop&q=80&w=800" className="rounded-3xl shadow-2xl border-4 border-white/10" alt="Inclusão" />
      </div>
      <div className="lg:w-1/2 space-y-8">
        <h2 className="font-title text-4xl md:text-6xl text-white">PARA QUEM É <span className="cora">O EVENTO?</span></h2>
        <p className="text-lg md:text-xl font-body text-gray-100 leading-relaxed">
          Do iniciante ao avançado, todos os níveis de conhecimento são bem-vindos no confeitar Brasil.
        </p>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-x-8 gap-y-4">
          {[
            "Apaixonados na cultura gastronomica.",
            "Sonha em viver da gastronomia",
            "Deseja empreender em casa com segurança",
            "Quer conhecer oportunidades reais de geração de renda",
            "Busca aumentar sua renda e conquistar liberdade financeira",
            "Deseja transformar sua arte em um negócio lucrativo",
            "Ama confeitaria/gastronomia e quer evoluir tecnicamente",
            "Precisa de estratégia, técnica e networking para crescer"
          ].map((item, i) => (
            <div key={i} className="flex items-start gap-3 text-sm md:text-base font-semibold">
              <div className="bg-[#FF00E8] rounded-full p-1 mt-0.5 shrink-0"><Check size={14} className="text-white" /></div>
              <span>{item}</span>
            </div>
          ))}
        </div>
        
        <div className="flex flex-col md:flex-row items-center gap-8 pt-4">
          <a href="#ingresso" className="btn-brand animate-pulse-custom w-full md:w-auto px-10 py-5 rounded-xl text-lg text-center">SIM, ESSE EVENTO É PARA MIM!</a>
          <ClassificationBadge className="scale-90" />
        </div>
      </div>
    </div>
  </section>
);

const RecapSection = () => {
  const cards = [
    {
      title: "360° DE CONHECIMENTO",
      desc: "Workshops, palestras, aulas-show e mentorias com os melhores do Brasil.",
      icon: <Lightbulb className="yellow-text" size={28} />
    },
    {
      title: "360° DE PRÁTICA E ESTRATÉGIA",
      desc: "Técnicas, negócios, gestão, vendas, branding, posicionamento e muito mais.",
      icon: <Target className="yellow-text" size={28} />
    },
    {
      title: "360° DE IMPACTO E GERAÇÃO DE RENDA",
      desc: "Aprenda a transformar sua paixão em um negócio sólido e lucrativo, inspirando outras pessoas ao seu redor.",
      icon: <TrendingUp className="yellow-text" size={28} />
    },
    {
      title: "360° DE OPORTUNIDADES REAIS",
      desc: "Networking, parras, demonstrações ao vivo e um ambiente repleto de possibilidades.",
      icon: <RefreshCw className="yellow-text" size={28} />
    }
  ];

  return (
    <section className="py-24 bg-[#600060]">
      <div className="container mx-auto px-6">
        <div className="text-center mb-16">
          <h2 className="font-title text-4xl md:text-6xl mb-6 text-white">VEJA COMO FOI A <span className="cora">ÚLTIMA EDIÇÃO</span></h2>
          <h3 className="text-xl md:text-3xl font-body text-gray-300">Um Evento 360° Para Transformar Sua Vida</h3>
        </div>

        <div className="max-w-5xl mx-auto mb-20 aspect-video rounded-3xl overflow-hidden shadow-[0_0_60px_rgba(255,204,0,0.1)] border border-white/10">
          <iframe 
            width="100%" 
            height="100%" 
            src="https://www.youtube.com/embed/LtBlgLBxZdY" 
            title="Ultimo Evento Confeitar Minas" 
            frameBorder="0" 
            allow="accelerometer; autoplay; clipboard-write; encrypted-media; gigroscope; picture-in-picture; web-share" 
            referrerPolicy="strict-origin-when-cross-origin" 
            allowFullScreen
          ></iframe>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {cards.map((card, i) => (
            <div key={i} className="glass-card p-8 flex flex-col items-start hover:scale-105 transition-transform duration-300">
              <div className="mb-6 p-3 bg-white/5 rounded-xl">
                {card.icon}
              </div>
              <h4 className="font-title text-lg mb-4 text-[#FFCC00] leading-tight">{card.title}</h4>
              <p className="text-gray-300 font-body text-sm leading-relaxed">{card.desc}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

const HostSection = () => (
  <section className="py-24 bg-[#9900CC] relative overflow-hidden">
    <div className="container mx-auto px-6">
      <div className="flex flex-col lg:flex-row gap-16 items-center">
        <div className="lg:w-1/2 relative">
          <div className="absolute -inset-4 bg-gradient-to-tr from-[#FF00E8] to-[#FFCC00] opacity-20 blur-2xl rounded-full"></div>
          <img 
            src="https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?auto=format&fit=crop&q=80&w=800&h=1000" 
            className="relative rounded-3xl shadow-2xl border-2 border-white/10 grayscale hover:grayscale-0 transition-all duration-700" 
            alt="Dani Formigueiro" 
          />
        </div>
        <div className="lg:w-1/2 space-y-8">
          <div className="space-y-2">
            <h2 className="font-title text-4xl md:text-6xl text-white">CONHEÇA <span className="cora">DANI FORMIGUEIRO</span></h2>
            <h3 className="text-xl md:text-2xl font-body text-gray-200 italic">Conheça a Anfitriã que está a frente do Evento.</h3>
          </div>
          <div className="space-y-6 text-gray-200 font-body text-lg leading-relaxed">
            <p><span className="font-bold text-white">Dani Formigueiro</span> é empreendedora e referência nacional no fortalecimento do empreendedorismo feminino no lar.</p>
            <p>Fundadora do <span className="font-bold text-white">Empreendendo no Lar</span>, Dani iniciou sua jornada em 2016 com uma simples comunidade no Facebook e transformou esse projeto em um movimento que já impactou mais de 600 mil vidas em 10 anos de atuação.</p>
            
            <div className="p-8 glass-card border-l-4 border-[#FF00E8] relative">
              <Quote className="absolute top-4 right-4 text-white/10" size={48} />
              <p className="text-white font-bold italic text-xl">
                "Acredito que toda mulher tem potencial para ser protagonista da própria história. O Confeitar Brasil é a prova viva de que quando nos unimos, crescemos juntas."
              </p>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 pt-8">
            <div className="flex flex-col items-center text-center gap-3">
              <div className="w-16 h-16 bg-white/5 rounded-full flex items-center justify-center p-3 border border-white/10">
                <img src="input_file_0.png" className="w-full grayscale brightness-200 object-contain" alt="Confeitar Brasil" />
              </div>
              <span className="text-[10px] font-black uppercase tracking-widest text-gray-200">Criadora do Confeitar Brasil</span>
            </div>
            <div className="flex flex-col items-center text-center gap-3">
              <div className="w-16 h-16 bg-white/5 rounded-full flex items-center justify-center p-3 border border-white/10">
                <img src="input_file_0.png" className="w-full grayscale brightness-200 object-contain" alt="Empreendendo Lar" />
              </div>
              <span className="text-[10px] font-black uppercase tracking-widest text-gray-200">Fundadora do Empreendendo no lar</span>
            </div>
            <div className="flex flex-col items-center text-center gap-3">
              <div className="w-16 h-16 bg-white/5 rounded-full flex items-center justify-center p-3 border border-white/10">
                <img src="https://imagizer.imageshack.com/img923/6530/p6k13N.png" className="w-full grayscale brightness-200 object-contain" alt="Revista Confeitar" />
              </div>
              <span className="text-[10px] font-black uppercase tracking-widest text-gray-200">Liderando o maior movimento</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>
);

const OrganizationSection = () => (
  <section className="py-24 bg-[#600060]">
    <div className="container mx-auto px-6">
      <div className="flex flex-col lg:flex-row-reverse gap-16 items-start mb-16">
        <div className="lg:w-1/2 flex flex-col items-center lg:mt-[-40px]">
          <div className="relative group w-full">
            <div className="absolute -inset-1 bg-gradient-to-r from-[#FF00E8] to-[#FFCC00] rounded-3xl blur opacity-25 group-hover:opacity-50 transition duration-1000"></div>
            <img 
              src="https://images.unsplash.com/photo-1542744173-8e7e53415bb0?auto=format&fit=crop&q=80&w=1000&h=600" 
              className="relative rounded-3xl shadow-2xl border border-white/10 w-full" 
              alt="Movimento Empreendendo no Lar" 
            />
          </div>
          <div className="mt-8 flex flex-col items-center">
             <div className="h-28 md:h-36 w-auto bg-white/5 border border-white/10 p-4 rounded-xl flex items-center justify-center shadow-lg">
                <img src="input_file_0.png" className="max-h-full grayscale brightness-200" alt="Empreendendo no Lar" />
             </div>
          </div>
        </div>
        <div className="lg:w-1/2 space-y-8">
          <h2 className="font-title text-4xl md:text-6xl text-white">QUEM REALIZA O <br/><span className="cora">CONFEITAR BRASIL?</span></h2>
          <div className="space-y-6 text-gray-200 font-body text-lg leading-relaxed">
            <p>O Confeitar Brasil é realizado pelo <span className="font-bold text-white">Empreendendo no Lar</span>, um movimento que nasceu in 2016, a partir de uma comunidade no Facebook, com um propósito claro: capacitar, valorizar e colocar mulheres no centro do protagonismo econômico.</p>
            <p>Em 2017, o projeto realizou o primeiro evento de empreendedorismo para confeiteiras do Brasil, criando um marco histórico para a confeitaria e o empreendedorismo feminino no país.</p>
            <p>Ao longo de 10 anos de atuação, o Empreendendo no Lar já realizou quase 80 eventos, impactando mais de 600 mil vidas, por meio de oficinas, palestras, mentorias, congressos, feiras e programas de capacitação.</p>
            
            <div className="p-8 glass-card bg-white/5 italic font-bold text-white border-l-4 border-[#FFCC00]">
              "O projeto acredita que o lar não é limite — é ponto de partida. Que quando uma mulher cresce, toda uma rede cresce with ela."
            </div>
          </div>
        </div>
      </div>
      <div className="flex justify-center mt-12">
        <a href="#ingresso" className="btn-brand animate-pulse-custom px-12 py-6 rounded-2xl text-xl md:text-2xl shadow-[0_0_40px_rgba(255,204,0,0.2)] text-center">
          QUERO FAZER PARTE DESSE MOVIMENTO
        </a>
      </div>
    </div>
  </section>
);

const ExperienceSection = () => {
  const experiences = [
    { title: "7 Arenas de Imersão", desc: "Conhecimento estratégico dividido em áreas especializadas para seu crescimento.", icon: <Target className="yellow-text" /> },
    { title: "Workshops Exclusivos", desc: "Mão na massa com profissionais de ponta em sessões práticas detalhadas.", icon: <Palette className="yellow-text" /> },
    { title: "Concursos e Competições", desc: "Bolos Artísticos, Decoração de Festa e o eletrizante 'Confeitar ao Vivo: O Combate'.", icon: <Trophy className="yellow-text" /> },
    { title: "Mentorias e Masterclasses", desc: "Sessões íntimas e exclusivas com empreendedores que já trilharam o caminho do sucesso.", icon: <Users className="yellow-text" /> },
    { title: "Palestras Inspiradoras", desc: "Histórias reais de transformation, superação e crescimento acelerado.", icon: <Mic className="yellow-text" /> },
    { title: "Feira de Expositores", desc: "Insumos, equipamentos, tecnologia e novidades do mercado em primeira mão.", icon: <ShoppingBag className="yellow-text" /> }
  ];

  return (
    <section className="py-24 bg-[#9900CC] border-y border-white/5">
      <div className="container mx-auto px-6">
        <div className="text-center mb-16 space-y-4">
          <h2 className="font-title text-4xl md:text-6xl text-white uppercase">O QUE VOCÊ VAI <span className="cora">VIVER?</span></h2>
          <p className="text-xl md:text-2xl font-body text-[#FFCC00] font-bold">PROGRAMAÇÃO COMPLETA</p>
          <p className="text-gray-200 font-body text-lg">O Que Você Vai Viver no Confeitar Brasil 2026</p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {experiences.map((exp, i) => (
            <div key={i} className="glass-card p-8 group hover:border-[#FFCC00]/50 transition-all duration-300">
              <div className="w-12 h-12 bg-white/5 rounded-xl flex items-center justify-center mb-6 group-hover:scale-110 transition-transform">
                {exp.icon}
              </div>
              <h4 className="font-title text-xl mb-3 text-white">{exp.title}</h4>
              <p className="text-gray-300 font-body text-sm leading-relaxed">{exp.desc}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

const ArenasLayout = () => {
  const arenas = [
    { name: "Arena Senai", desc: "Espaço SENAI trará uma programação completa de aulas shows em confeitaria, panificação e gestão, com foco em aumento de produtividade, padronização e lucratividade.", img: "https://picsum.photos/seed/senai/1080/1350" },
    { name: "Arena Confeitar", desc: "Aprenda <strong>confeitaria prática</strong> com foco real em vendas: de bolos festivos a tortas comerciais e <strong>receitas inclusivas</strong> que atendem a todos os públicos.", img: "https://picsum.photos/seed/confeitar/1080/1350" },
    { name: "Arena do Cacau", desc: "Especialize-se na arte do <strong>chocolate profissional</strong>. Da origem da amêndoa à <strong>temperagem perfeita</strong>, focando em ovos de páscoa e bombons finos.", img: "https://picsum.photos/seed/cacau/1080/1350" },
    { name: "Arena Empreendendo no Lar", desc: "O coração estratégico do evento: <strong>gestão financeira</strong>, marketing digital, <strong>precificação correta</strong> e saúde da mulher empreendedora.", img: "https://picsum.photos/seed/lar/1080/1350" },
    { name: "Arena Mart Minas", desc: "Descubra <strong>receitas práticas e lucrativas</strong> de alto giro. Otimize seus custos e aprenda a criar produtos de <strong>venda rápida</strong> para o dia a dia.", img: "https://picsum.photos/seed/mart/1080/1350" },
    { name: "Arena da Panificação", desc: "Explore o mundo dos <strong>pães artesanais</strong> e fermentação natural. Domine a técnica de broas, roscas e pães rústicos com <strong>identidade brasileira</strong>.", img: "https://picsum.photos/seed/bread/1080/1350" },
    { name: "Arena Combate", desc: "Assista e aprenda com as <strong>disputas ao vivo</strong> de decoração. A pressão da plateia e a técnica se unem para mostrar o que há de mais <strong>inovador no mercado</strong>.", img: "https://picsum.photos/seed/combat/1080/1350" }
  ];

  return (
    <section className="py-24 bg-[#600060] relative overflow-hidden border-y border-white/5">
      <div className="container mx-auto px-6 mb-20">
        <h2 className="font-title text-4xl md:text-7xl text-center uppercase leading-tight text-white">
          <span className="text-[#FFCC00]">7 arenas simultâneas.</span> <br/>
          <span className="cora">Você monta sua experiência.</span>
        </h2>
      </div>
      
      <div className="container mx-auto px-6 space-y-12 max-w-7xl">
        {arenas.map((arena, i) => (
          <div 
            key={i} 
            className={`flex flex-col md:flex-row items-center gap-0 overflow-hidden rounded-[30px] border border-white/10 transition-all duration-500 hover:border-[#FFCC00]/20 ${i % 2 === 1 ? 'md:flex-row-reverse' : ''}`}
            style={{ background: 'linear-gradient(145deg, #600060, #7c007c)' }}
          >
            <div className="w-full md:w-1/2 aspect-[1080/1350] overflow-hidden">
               <img src={arena.img} className="w-full h-full object-cover grayscale hover:grayscale-0 transition-all duration-1000" alt={arena.name} />
            </div>
            
            <div className="w-full md:w-1/2 p-10 md:p-16 lg:p-24 flex flex-col justify-center">
               <h3 className="font-title text-3xl md:text-4xl lg:text-5xl text-white uppercase leading-tight mb-8">
                 {arena.name.split(' ')[0]} <br/> <span className="cora">{arena.name.split(' ').slice(1).join(' ')}</span>
               </h3>
               <p 
                 className="text-gray-200 text-lg lg:text-xl font-body leading-relaxed"
                 dangerouslySetInnerHTML={{ __html: arena.desc }}
               />
            </div>
          </div>
        ))}
      </div>
    </section>
  );
};

const PastSpeakersMarquee = () => {
  const speakers = [
    { name: "Léo Vilela (Flakes)", bio: "CEO da Flakes Brazil e referência in inovação no varejo e confeitaria artística.", img: "https://picsum.photos/seed/leo/1080/1350" },
    { name: "Beca Milano", bio: "Chef confeiteira e jurada de TV, especialista em bolos de casamento e alta confeitaria.", img: "https://picsum.photos/seed/beca/1080/1350" },
    { name: "Mara Cakes", bio: "Empresária e fundadora de uma das maiores franquias de confeitaria do Brasil, expert em gestão e posicionamento de marca.", img: "https://picsum.photos/seed/mara/1080/1350" },
    { name: "Simone Izumi", bio: "Fundadora da Chocolatria, especialista em chocolates finos e autora focada na excelência técnica e sensorial.", img: "https://picsum.photos/seed/simone/1080/1350" },
    { name: "João Barcelos", bio: "Especialista em gestão de padarias e confeitarias, focado em aumento de lucratividade e processos produtivos.", img: "https://picsum.photos/seed/barcelos/1080/1350" },
    { name: "Tathi Fabulosa", bio: "Expert em coloração de chantilly e técnicas de decoração vibrantes que transformam bolos em arte.", img: "https://picsum.photos/seed/tathi/1080/1350" }
  ];

  const duplicatedSpeakers = [...speakers, ...speakers];

  return (
    <section className="py-24 bg-[#4D004D] overflow-hidden border-y border-white/10">
      <div className="container mx-auto px-6 mb-16 text-center">
        <h2 className="font-title text-2xl md:text-4xl lg:text-5xl text-white leading-tight">
          NOMES QUE JÁ PASSARAM <br className="md:hidden" /> PELAS <span className="yellow-text">ÚLTIMAS EDIÇÕES:</span>
        </h2>
      </div>

      <div className="marquee-container py-20 flex overflow-hidden">
        <div className="marquee-photos flex gap-8 items-stretch">
          {duplicatedSpeakers.map((speaker, i) => (
            <div 
              key={i} 
              className="w-72 md:w-80 flex-shrink-0 bg-[#600060] border border-white/10 rounded-3xl overflow-hidden glass-card flex flex-col group hover:border-[#FFCC00]/50 transition-colors duration-500"
            >
              <div className="aspect-[4/5] overflow-hidden">
                <img 
                  src={speaker.img} 
                  className="w-full h-full object-cover grayscale group-hover:grayscale-0 transition-all duration-700" 
                  alt={speaker.name} 
                />
              </div>
              <div className="p-6 md:p-8 flex flex-col items-center text-center flex-grow justify-center bg-gradient-to-b from-transparent to-[#4D004D]/50">
                <h4 className="font-title text-base md:text-lg text-[#FFCC00] mb-3 leading-tight uppercase tracking-tight">{speaker.name}</h4>
                <p className="text-gray-200 text-xs md:text-sm font-body leading-relaxed whitespace-normal">{speaker.bio}</p>
              </div>
            </div>
          ))}
        </div>
      </div>

      <div className="flex justify-center mt-16 px-6">
        <a href="#ingresso" className="btn-brand animate-pulse-custom px-12 py-5 rounded-full text-lg md:text-xl shadow-2xl uppercase tracking-widest text-center">
          GARANTIR MEU LUGAR EM 2026
        </a>
      </div>
    </section>
  );
};

const SponsorshipAndSupport = () => (
  <div className="bg-[#4D004D]">
    {/* Sponsorship Section */}
    <section className="py-24 border-b border-white/10">
      <div className="container mx-auto px-6 text-center">
        <h2 className="font-title text-3xl md:text-5xl text-white mb-6 uppercase leading-tight">
          DESEJA QUE SUA MARCA FAÇA <br/> <span className="cora">PARTE DESSA TRANSFORMAÇÃO?</span>
        </h2>
        <div className="max-w-2xl mx-auto mb-10">
           <p className="text-gray-300 font-body text-lg md:text-xl">
             O Confeitar Brasil 2026 é uma oportunidade perfeita para sua marca se conectar com milhares de empreendedores motivados e em crescimento.
           </p>
           <p className="text-gray-400 font-body text-sm mt-4">Clique no botão abaixo e fale com a equipe do evento:</p>
        </div>
        <a 
          href="https://wa.me/55319852695?text=Ol%C3%A1%2C%20quero%20ser%20um%20dos%20patrocinadores%20do%20Confeitar%20Brasil%202026." 
          target="_blank" 
          rel="noreferrer"
          className="inline-block bg-[#2fb16b] text-white font-black px-10 py-5 rounded-full text-lg animate-pulse-green shadow-xl transition-transform hover:scale-105"
        >
          INFORMAÇÕES SOBRE PATROCÍNIO
        </a>
      </div>
    </section>

    {/* Support Section */}
    <section className="py-24">
      <div className="container mx-auto px-6 text-center">
        <div className="flex justify-center mb-8">
           <div className="w-24 h-24 bg-[#25d366]/20 rounded-full flex items-center justify-center animate-pulse-green">
             <MessageCircle size={64} className="text-[#25d366]" />
           </div>
        </div>
        <h2 className="font-title text-3xl md:text-5xl text-white mb-6 uppercase leading-tight">
          ESTÁ COM DÚVIDA PARA <br/> <span className="yellow-text">GARANTIR SEU INGRESSO?</span>
        </h2>
        <p className="text-gray-300 font-body text-lg md:text-xl mb-10 max-w-2xl mx-auto">
          Converse agora com um especialista do nosso time
        </p>
        <a 
          href="https://wa.me/5531988845413?text=Ol%C3%A1%2C%20preciso%20de%20ajuda%20para%20comprar%20ingressos%20do%20Confeitar%20Brasil%202026." 
          target="_blank" 
          rel="noreferrer"
          className="inline-block bg-[#25d366] text-white font-black px-10 py-5 rounded-full text-lg animate-pulse-green shadow-xl transition-transform hover:scale-105"
        >
          QUERO FALAR PELO WHATSAPP
        </a>
      </div>
    </section>
  </div>
);

const InclusionSection = () => (
  <section className="py-24 bg-[#600060] overflow-hidden">
    <div className="container mx-auto px-6">
      <div className="flex flex-col lg:flex-row gap-16 items-center">
        <div className="lg:w-1/2 relative">
          <div className="absolute -inset-4 bg-[#FF00E8]/10 blur-3xl rounded-full"></div>
          <img 
            src="https://images.unsplash.com/photo-1576091160550-2173dba999ef?auto=format&fit=crop&q=80&w=800&h=1000" 
            className="relative rounded-3xl shadow-2xl border-4 border-white/5 object-cover aspect-[4/5] w-full" 
            alt="Inclusão e Acessibilidade" 
          />
        </div>
        <div className="lg:w-1/2 space-y-10">
          <div className="space-y-4">
            <h2 className="font-title text-4xl md:text-6xl text-white">INCLUSÃO E <br/><span className="cora">ACESSIBILIDADE</span></h2>
            <p className="text-gray-200 font-body text-xl leading-relaxed">
              O Confeitar Brasil 2026 acredita que oportunidades de conhecimento e crescimento devem estar ao alcance de todas as pessoas. Por isso, oferecemos programação inclusiva com acessibilidade e acolhimento.
            </p>
          </div>

          <div className="space-y-8">
            <div className="glass-card p-8 border-l-4 border-[#FFCC00] hover:bg-white/5 transition-colors">
              <div className="flex items-center gap-4 mb-4">
                <div className="p-3 bg-white/5 rounded-lg"><Heart className="yellow-text" size={24}/></div>
                <h4 className="font-title text-xl text-white">AULAS PARA PESSOAS COM DOWN</h4>
              </div>
              <p className="text-gray-300 font-body text-base">
                Workshops exclusivos adaptados para pessoas com Síndrome de Down, com metodologia especializada e ambiente acolhedor. Porque talento não tem limites.
              </p>
            </div>

            <div className="glass-card p-8 border-l-4 border-[#FF00E8] hover:bg-white/5 transition-colors">
              <div className="flex items-center gap-4 mb-4">
                <div className="p-3 bg-white/5 rounded-lg"><HandMetal className="cora" size={24}/></div>
                <h4 className="font-title text-xl text-white">AULAS COM INTÉRPRETE DE LIBRAS</h4>
              </div>
              <p className="text-gray-300 font-body text-base">
                Programação completa acessível para a comunidade surda, com intérpretes de Libras presentes em todas as atividades. Conhecimento sem barreiras.
              </p>
            </div>
          </div>

          <div className="p-6 bg-white/5 rounded-2xl border border-white/10 text-center">
            <p className="font-body text-white text-lg italic">
              "Nosso compromisso é com a inclusão real. Aqui, todas são bem-vindas, respeitadas e protagonistas."
            </p>
          </div>
        </div>
      </div>
    </div>
  </section>
);

const ESGSection = () => {
  const esgItems = [
    {
      title: "AMBIENTAL",
      subtitle: "(AMBIENTAL)",
      color: "bg-[#9900CC]", 
      items: ["Valorização da produção local", "Cadeias encurtadas", "Sustentabilidade"],
      icon: <Leaf className="text-white mb-4" size={40} />
    },
    {
      title: "SOCIAL",
      subtitle: "(SOCIAL)",
      color: "bg-[#FF00E8]", 
      items: ["Geração de renda feminina", "Inclusão produtiva", "Impacto em famílias"],
      icon: <Heart className="text-white mb-4" size={40} />
    },
    {
      title: "GOVERNANÇA",
      subtitle: "(GOVERNANÇA)",
      color: "bg-[#FF6600]", 
      items: ["Estrutura sólida", "Parcerias institucionais", "Transparência"],
      icon: <ShieldCheck className="text-white mb-4" size={40} />
    }
  ];

  return (
    <section className="py-24 bg-white relative overflow-hidden">
      <div className="container mx-auto px-6">
        <div className="text-center mb-16 relative">
          <h2 className="font-title text-2xl sm:text-4xl md:text-6xl text-[#600060] uppercase leading-tight mb-2 max-w-2xl mx-auto">
            O Confeitar Brasil <br className="block md:hidden"/> também tem <br/> <span className="text-[#9900CC]">práticas ESG</span>
          </h2>
          <div className="w-24 h-1.5 bg-[#FFCC00] mx-auto mt-6 rounded-full"></div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 max-w-7xl mx-auto">
          {esgItems.map((card, i) => (
            <div key={i} className={`${card.color} p-10 rounded-[30px] shadow-2xl flex flex-col items-center text-center transform transition-transform hover:-translate-y-2 duration-300`}>
              <h3 className="text-white font-title text-3xl md:text-4xl mb-1 tracking-tighter uppercase">{card.title}</h3>
              <p className="text-white/80 font-body text-xs md:text-sm font-bold uppercase tracking-widest mb-8">{card.subtitle}</p>
              
              <ul className="space-y-6 w-full text-left">
                {card.items.map((item, idx) => (
                  <li key={idx} className="flex items-center gap-4 text-white font-body text-lg md:text-xl font-bold">
                    <div className="bg-white/20 rounded-full p-1.5 shrink-0">
                      <Check className="text-white" size={18} strokeWidth={4} />
                    </div>
                    <span>{item}</span>
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

const LocationSection = () => (
  <section className="py-24 bg-white text-black">
    <div className="container mx-auto px-6">
      <div className="text-center mb-16">
        <h2 className="font-title text-4xl md:text-6xl uppercase leading-tight">
          <span className="text-[#FFCC00]">Onde e Quando</span> <br className="md:hidden"/>
          <span className="text-[#600060]"> Acontece?</span>
        </h2>
      </div>
      
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-stretch max-w-7xl mx-auto">
        <div className="bg-white p-8 md:p-12 rounded-[40px] shadow-[0_20px_50px_rgba(0,0,0,0.08)] border border-gray-100 flex flex-col justify-between">
          <div>
            <h3 className="text-[#600060] font-bold text-3xl mb-12">Informações do Evento</h3>
            
            <div className="space-y-12">
              <div className="flex gap-6 items-start">
                <div className="w-14 h-14 bg-[#f3e5f5] rounded-full flex items-center justify-center shrink-0 shadow-sm">
                  <MapPin className="text-[#600060]" size={28} />
                </div>
                <div>
                  <h4 className="font-bold text-xl text-[#600060] uppercase mb-2 tracking-tight">LOCAL</h4>
                  <p className="text-gray-700 text-lg font-semibold">Expominas BH</p>
                  <p className="text-gray-500 text-base">Av. Amazonas, 6.200 – Gameleira, Belo Horizonte – MG</p>
                </div>
              </div>

              <div className="flex gap-6 items-start">
                <div className="w-14 h-14 bg-[#f3e5f5] rounded-full flex items-center justify-center shrink-0 shadow-sm">
                  <Calendar className="text-[#600060]" size={28} />
                </div>
                <div>
                  <h4 className="font-bold text-xl text-[#600060] uppercase mb-2 tracking-tight">DADOS</h4>
                  <p className="text-gray-700 text-lg font-semibold italic">03, 04 e 05 de Março de 2026</p>
                </div>
              </div>

              <div className="flex gap-6 items-start">
                <div className="w-14 h-14 bg-[#f3e5f5] rounded-full flex items-center justify-center shrink-0 shadow-sm">
                  <Clock className="text-[#600060]" size={28} />
                </div>
                <div>
                  <h4 className="font-bold text-xl text-[#600060] uppercase mb-2 tracking-tight">HORÁRIOS</h4>
                  <div className="space-y-1">
                    <p className="text-gray-700 text-lg">Dia 3 e 4: <span className="font-bold">13h às 21h</span></p>
                    <p className="text-gray-700 text-lg">Dia 5: <span className="font-bold">13h às 19h</span></p>
                  </div>
                </div>
              </div>
            </div>
          </div>
          
          <div className="mt-12 pt-10 border-t border-gray-100">
             <p className="text-gray-600 leading-relaxed text-lg">
                O <span className="font-bold">Expominas</span> é referência em conforto e acessibilidade. Com estacionamento amplo, segurança 24h e fácil acesso via transporte público e aplicativos.
             </p>
          </div>
        </div>

        <div className="flex flex-col gap-6">
          <div className="relative rounded-[40px] overflow-hidden shadow-2xl group flex-1">
             <img src="https://images.unsplash.com/photo-1541341031263-d1df52328104?auto=format&fit=crop&q=80&w=1200&h=800" className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-1000" alt="Expominas BH" />
             <div className="absolute bottom-8 left-8 bg-white/95 backdrop-blur px-8 py-3 rounded-full font-bold text-[#600060] shadow-xl text-lg">
                Expominas BH
             </div>
          </div>
          <div className="rounded-[40px] overflow-hidden shadow-2xl border border-gray-100 h-[380px]">
            <iframe 
               src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3750.844783457176!2d-44.00034402391054!3d-19.93098528145892!2m3!1f0!2f0!3f0!3m2!i1024!2i768!4f13.1!3m3!1m2!1s0xa6976f9d8544d1%3A0xc3f587d188981b2!2sExpominas%20Belo%20Horizonte!5e0!3m2!1spt-BR!2sbr!4v1715800000000!5m2!1spt-BR!2sbr" 
               width="100%" 
               height="100%" 
               style={{ border: 0 }} 
               allowFullScreen 
               loading="lazy" 
               referrerPolicy="no-referrer-when-downgrade"
            ></iframe>
          </div>
        </div>
      </div>
    </div>
  </section>
);

const Pricing = () => {
  const commonFeatures = [
    "Acesso aos 3 dias de evento (03, 04 e 05 de março)",
    "Entrada livre em todas as 7 Arenas de Conhecimento",
    "Participação em workshops exclusivos",
    "Acesso à feira de expositores",
    "Participação em concursos e competições ao vivo",
    "Suporte via WhatsApp e e-mail"
  ];

  return (
    <section id="ingresso" className="py-24 bg-gradient-to-b from-[#9900CC] to-[#600060]">
      <div className="container mx-auto px-6 text-center mb-16">
        <h2 className="font-title text-4xl md:text-7xl mb-6 text-white">ESCOLHA SEU <span className="cora">INGRESSO</span></h2>
        <p className="font-body text-xl md:text-2xl text-gray-200 max-w-3xl mx-auto">
          Garanta Seu Lugar no Maior Evento de Empreendedorismo Gastronômico do Brasil
        </p>
      </div>
      
      <div className="container mx-auto px-6 grid grid-cols-1 lg:grid-cols-2 gap-12 max-w-6xl">
        {/* Card Standard */}
        <div className="glass-card p-10 border-2 border-white/10 relative overflow-hidden flex flex-col">
          <div className="absolute top-0 right-0 overflow-hidden w-40 h-40 pointer-events-none">
            <div className="bg-[#FF00E8] text-white text-[10px] font-black py-2 px-10 absolute top-8 right-[-40px] rotate-45 text-center w-[200px] shadow-lg tracking-widest uppercase">
              Lote 02
            </div>
          </div>
          
          <div className="mb-8 text-center">
            <h3 className="font-title text-3xl mb-2 text-white">INGRESSO PADRÃO</h3>
            <p className="font-body text-gray-400 uppercase tracking-widest text-xs">Passaporte para 3 dias de Evento</p>
          </div>
          
          <div className="mb-10 text-center">
            <div className="text-6xl font-title text-white mb-2">R$ 97,00</div>
            <p className="font-body text-gray-300 italic text-lg">ou em 12 x de R$ 10,03 * no cartão</p>
          </div>
          
          <a 
            href="https://pay.hotmart.com/X104250583U?off=2xqae4aa"
            target="_blank"
            rel="noreferrer"
            className="btn-brand animate-pulse-custom w-full py-6 rounded-2xl text-xl mb-12 flex items-center justify-center gap-3 text-center"
          >
            GARANTIR INGRESSO
            <ArrowRight size={20} />
          </a>
          
          <ul className="space-y-4 flex-1 mb-8">
            {commonFeatures.map((feature, i) => (
              <li key={i} className="flex items-start gap-3 text-gray-200 font-body text-sm md:text-base">
                <div className="bg-[#FF00E8] rounded-full p-1 mt-0.5 shrink-0"><Check size={14} className="text-white" /></div>
                <span>{feature}</span>
              </li>
            ))}
          </ul>

          <div className="flex flex-col items-center gap-2 pt-6 border-t border-white/10">
            <div className="flex items-center gap-3 text-gray-400 font-bold uppercase tracking-wider text-sm">
              <Lock size={16} /> COMPRA 100% SEGURA
            </div>
          </div>
        </div>

        {/* Card Combo */}
        <div className="glass-card p-10 border-2 border-white/10 relative overflow-hidden flex flex-col transform lg:scale-105 shadow-[0_0_60px_rgba(255,204,0,0.15)] z-10">
          <div className="absolute top-0 right-0 overflow-hidden w-40 h-40 pointer-events-none">
            <div className="bg-[#FF00E8] text-white text-[10px] font-black py-2 px-10 absolute top-8 right-[-40px] rotate-45 text-center w-[200px] shadow-lg tracking-widest uppercase">
              Lote 02
            </div>
          </div>
          
          <div className="mb-8 text-center mt-4">
            <h3 className="font-title text-3xl mb-2 text-white">COMBO 5 INGRESSOS PADRÃO</h3>
            <p className="font-body text-gray-400 uppercase tracking-widest text-xs">Passaporte para 3 dias de Evento</p>
          </div>
          
          <div className="mb-10 text-center">
            <div className="text-6xl font-title text-white mb-2">R$ 64,90</div>
            <p className="font-body text-gray-300 italic text-lg mb-2">ou em 12 x de R$ 42,65 * no cartão</p>
            <div className="inline-block bg-[#2fb16b]/10 text-[#2fb16b] px-4 py-1 rounded-lg font-black text-sm border border-[#2fb16b]/30 uppercase tracking-widest">
              Economia de 50%
            </div>
          </div>
          
          <a 
            href="https://pay.hotmart.com/X104250583U?off=12m1mi4k"
            target="_blank"
            rel="noreferrer"
            className="btn-brand animate-pulse-custom w-full py-6 rounded-2xl text-xl mb-12 flex items-center justify-center gap-3 text-center"
          >
            GARANTIR INGRESSO
            <ArrowRight size={20} />
          </a>
          
          <ul className="space-y-4 flex-1 mb-8">
            {commonFeatures.map((feature, i) => (
              <li key={i} className="flex items-start gap-3 text-gray-200 font-body text-sm md:text-base">
                <div className="bg-[#FF00E8] rounded-full p-1 mt-0.5 shrink-0"><Check size={14} className="text-white" /></div>
                <span>{feature}</span>
              </li>
            ))}
          </ul>

          <div className="flex flex-col items-center gap-2 pt-6 border-t border-white/10">
            <div className="flex items-center gap-3 text-gray-400 font-bold uppercase tracking-wider text-sm">
              <Lock size={16} /> COMPRA 100% SEGURA
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default function App() {
  const faqData = [
    {
      question: "O Confeitar Brasil é o mesmo que Confeitar Minas?",
      answer: "Sim! O evento cresceu e se tornou uma referência nacional. O que antes era Confeitar Minas, agora é o grandioso Confeitar Brasil, mantendo a mesma essência e qualidade que você já conhece."
    },
    {
      question: "Como faço para circular entre as arenas?",
      answer: "Você pode circular livremente entre todas as arenas durante os dias do evento. A programação detalhada será divulgada com antecedência para você montar sua agenda personalizada."
    },
    {
      question: "Haverá alimentação no local?",
      answer: "Sim. O Expominas conta com praça de alimentação completa. Também haverá degustações e experiências gastronômicas durante o evento."
    },
    {
      question: "O que está incluso no valor do ingresso?",
      answer: "O ingresso dá acesso aos 3 dias de evento, a todas as Arenas de Conhecimento, workshops, palestras, mentorias, concursos, área de exposição/feira e networking."
    },
    {
      question: "Posso parcelar o ingresso?",
      answer: "Sim! Aceitamos parcelamento facilitado através da plataforma Hotmart. Você pode conferir todas as opções de parcelamento diretamente na página de pagamento."
    },
    {
      question: "Qual a política de cancelamento?",
      answer: "A política de cancelamento e reembolso segue as diretrizes da plataforma Hotmart. Para mais detalhes, consulte os termos no momento da compra ou entre em contato pelo nosso suporte."
    }
  ];

  return (
    <div className="min-h-screen selection:bg-[#FF00E8] selection:text-white font-body bg-[#600060]">
      <div className="bg-[#Ff6600] py-3 text-center text-white font-black text-xs md:text-sm uppercase tracking-[0.2em] sticky top-0 z-[1000] shadow-xl">
        2º LOTE POR TEMPO LIMITADO • R$ 97,00 • GARANTA SUA VAGA AGORA
      </div>
      
      <Hero />
      <MarqueeText />
      <PhotoMarquee />
      <About />
      
      <CulturalConnection />

      <ForWhom />
      
      <WhatMovesUs />

      <section className="py-24 bg-[#9900CC]/50 text-center">
        <div className="container mx-auto px-6">
          <h2 className="font-title text-xl sm:text-2xl md:text-5xl mb-16 max-w-xs sm:max-w-none mx-auto leading-tight text-white text-center">
            Marcas que acreditam <br className="block sm:hidden"/> <span className="cora">no poder do empreendedorismo feminino:</span>
          </h2>
          
          <div className="flex flex-wrap justify-center items-center gap-12 md:gap-20 opacity-80 hover:opacity-100 transition-opacity duration-500 mb-20">
             <div className="flex flex-col items-center gap-4">
                <div className="bg-white p-4 rounded-2xl shadow-lg hover:scale-105 transition-transform">
                  <img src="input_file_0.png" className="h-20 md:h-28 object-contain" alt="Mart Minas" />
                </div>
                <span className="text-xs font-black uppercase tracking-widest opacity-60 text-white">Patrocinador Oficial</span>
             </div>
             <div className="flex flex-col items-center gap-4">
                <div className="bg-white p-4 rounded-2xl shadow-lg hover:scale-105 transition-transform">
                  <img src="input_file_1.png" className="h-20 md:h-28 object-contain" alt="1001 Festas" />
                </div>
                <span className="text-xs font-black uppercase tracking-widest opacity-60 text-white">Patrocinador Diamante</span>
             </div>
             <div className="flex flex-col items-center gap-4">
                <div className="bg-white p-4 rounded-2xl shadow-lg hover:scale-105 transition-transform">
                  <img src="input_file_2.png" className="h-20 md:h-28 object-contain" alt="Maria Chocolate" />
                </div>
                <span className="text-xs font-black uppercase tracking-widest opacity-60 text-white">Patrocinador Bronze</span>
             </div>
          </div>

          <div className="pt-16 border-t border-white/10">
            <h3 className="font-title text-xl md:text-2xl mb-10 text-gray-300 uppercase text-center">Apoio Institucional</h3>
            <div className="flex flex-wrap justify-center items-center gap-12 md:gap-24 opacity-60 grayscale hover:grayscale-0 transition-all duration-500">
               <div className="flex flex-col items-center gap-3">
                 <div className="bg-white p-4 rounded-xl w-40 h-20 flex items-center justify-center">
                   <img src="https://logodownload.org/wp-content/uploads/2014/04/senai-logo-1.png" className="max-h-full" alt="Senai" />
                 </div>
                 <span className="text-[10px] font-bold uppercase tracking-widest text-white">Senai</span>
               </div>
               <div className="flex flex-col items-center gap-3">
                 <div className="bg-white p-4 rounded-xl w-40 h-20 flex items-center justify-center">
                   <img src="https://amipao.com.br/wp-content/uploads/2021/04/logo-amipao.png" className="max-h-full" alt="Amipão" />
                 </div>
                 <span className="text-[10px] font-bold uppercase tracking-widest text-white">Amipão</span>
               </div>
            </div>
          </div>
        </div>
      </section>

      <RecapSection />
      <HostSection />
      <OrganizationSection />
      <ExperienceSection />
      <ArenasLayout />
      <PastSpeakersMarquee />
      <InclusionSection />
      <ESGSection />
      <LocationSection />
      <Pricing />

      <section className="py-24 bg-[#600060]">
        <div className="container mx-auto px-6 max-w-4xl">
          <div className="text-center mb-16">
             <h2 className="font-title text-4xl md:text-6xl mb-4 text-white uppercase">FAQ</h2>
             <h3 className="text-2xl font-body text-gray-300">Perguntas Frequentes</h3>
          </div>
          <div className="glass-card p-6 md:p-12">
            {faqData.map((faq, index) => (
              <FAQItem 
                key={index}
                question={faq.question} 
                answer={faq.answer} 
              />
            ))}
          </div>
        </div>
      </section>

      <SponsorshipAndSupport />

      <footer className="bg-[#4D004D] pt-24 pb-12 border-t border-white/5">
        <div className="container mx-auto px-6 text-center md:text-left">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-12 mb-16">
            <div className="col-span-1 md:col-span-2">
              <h4 className="font-title text-3xl mb-6 text-white uppercase">CONFEITAR <span className="cora">BRASIL</span></h4>
              <p className="text-gray-300 max-w-sm font-body leading-relaxed">
                O maior evento de confeitaria e empreendedorismo gastronômico do Brasil. Realização: Empreendendo no Lar.
              </p>
            </div>
            <div>
              <h5 className="font-title text-sm mb-8 cora uppercase">SIGA-NOS</h5>
              <div className="flex justify-center md:justify-start gap-4">
                 <a 
                   href="https://www.instagram.com/confeitarbrasiloficial/" 
                   target="_blank" 
                   rel="noreferrer"
                   className="w-10 h-10 rounded-full glass-card flex items-center justify-center hover:bg-[#FF00E8]/20 transition-all cursor-pointer text-white"
                 >
                   <Instagram size={18}/>
                 </a>
              </div>
            </div>
          </div>
          <div className="pt-12 border-t border-white/5 text-center md:text-left">
             <p className="text-gray-400 text-[10px] uppercase tracking-widest font-black">© 2026 CONFEITAR BRASIL • TODOS OS DIREITOS RESERVADOS</p>
          </div>
        </div>
      </footer>
    </div>
  );
}
